#Description of the data

beamlets_{TSchainRad,TSrad}: folders containing the outputs of each execution of both algorithms.

For each instance, there is a folder with its respective name (in this case, Liver_{03...10})

Each of these folders contains the outputs of all 30 executions.

The outputs are:
	- avals.x.txt  -> contains the number of objective function evaluations on that execution
	- beams.x.txt  -> contains the beam set of the best solution found by the algorithm on that execution
	- objs.x.txt   -> contains the objective functions values of the best solution of that execution, in this order: 
					  g, f_{1}, f_{3}, f_{4}


In the folder of each algorithm, there is also files named objs_Liver_yy.txt, which each one groups the values of all files objs.x.txt of the instance Liver_xx.

The root folder contains also the dose-volume histograms included in the paper, and the beamlet values that generated them. Recall that the instance used for generation was Liver_05, and the solution chosen was the one corresponding to the median.